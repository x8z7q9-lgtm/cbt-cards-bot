import os
import logging
from aiogram import Bot, Dispatcher, F, types
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.filters import Command
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.context import FSMContext
from aiogram.fsm.storage.memory import MemoryStorage

from openai import OpenAI

# Логирование
logging.basicConfig(level=logging.INFO)

# Переменные окружения
BOT_TOKEN = os.getenv("BOT_TOKEN")
OPENROUTER_KEY = os.getenv("OPENROUTER_KEY")

# Проверка
if not BOT_TOKEN:
    raise ValueError("BOT_TOKEN не найден в переменных окружения!")
if not OPENROUTER_KEY:
    raise ValueError("OPENROUTER_KEY не найден в переменных окружения!")

# Инициализация
bot = Bot(token=BOT_TOKEN)
dp = Dispatcher(storage=MemoryStorage())
client = OpenAI(base_url="https://openrouter.ai/api/v1", api_key=OPENROUTER_KEY)

# Хранилище карточек {user_id: [{neg:..., pos:..., flips:...}]}
user_cards = {}
# Режим редактирования {user_id: index}
edit_mode = {}

# --- FSM для добавления мысли ---
class AddThought(StatesGroup):
    waiting_for_thought = State()

# --- FSM для редактирования ---
class EditThought(StatesGroup):
    waiting_for_edit = State()

# Генерация альтернатив
def ai_generate(prompt: str):
    try:
        response = client.chat.completions.create(
            model="openai/gpt-4o-mini",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.8
        )
        return response.choices[0].message.content.strip().split("\n")
    except Exception as e:
        logging.error(f"AI error: {e}")
        return ["Ошибка генерации", "Попробуй снова", "Что-то пошло не так"]

# Главное меню
def main_menu():
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="➕ Добавить мысль", callback_data="add")],
        [InlineKeyboardButton(text="🃏 Карточки", callback_data="cards")]
    ])
    return kb

# Старт
@dp.message(Command("start"))
async def cmd_start(message: types.Message):
    user_cards[message.from_user.id] = []
    await message.answer("Привет! Я помогу тебе заменять негативные мысли на полезные убеждения.", reply_markup=main_menu())

# Добавление мысли
@dp.callback_query(F.data == "add")
async def add_thought_start(callback: types.CallbackQuery, state: FSMContext):
    await state.set_state(AddThought.waiting_for_thought)
    await callback.message.answer("Напиши свою негативную мысль:", reply_markup=main_menu())
    await callback.answer()

@dp.message(AddThought.waiting_for_thought)
async def add_thought_process(message: types.Message, state: FSMContext):
    neg = message.text.strip()
    alts = ai_generate(f"Человек думает: '{neg}'. Предложи 3 альтернативных убеждения.")

    kb = ReplyKeyboardMarkup(keyboard=[[KeyboardButton(text=alt)] for alt in alts], resize_keyboard=True)
    await message.answer("Выбери одно из альтернативных убеждений:", reply_markup=kb)

    await state.update_data(neg=neg, alts=alts)
    await state.clear()

# Выбор альтернативы
@dp.message(F.text)
async def process_alternative(message: types.Message):
    user_id = message.from_user.id
    for data in user_cards.get(user_id, []):
        if message.text == data["pos"]:
            return

    for data in (await dp.storage.get_data(bot=bot, user=message.from_user)).values():
        pass

    for alt in ["Ошибка генерации", "Попробуй снова", "Что-то пошло не так"]:
        if message.text == alt:
            return

    neg = None
    for row in message.reply_markup.keyboard if message.reply_markup else []:
        for button in row:
            if button.text == message.text:
                neg = "Неизвестно"
                break

    if not neg:
        return

    user_cards.setdefault(user_id, []).append({"neg": neg, "pos": message.text, "flips": 0})
    await message.answer("Карточка создана!", reply_markup=main_menu())

# Показ карточек
@dp.callback_query(F.data == "cards")
async def show_cards(callback: types.CallbackQuery):
    user_id = callback.from_user.id
    cards = user_cards.get(user_id, [])

    if not cards:
        await callback.message.answer("У тебя пока нет карточек.", reply_markup=main_menu())
        return

    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=c["neg"], callback_data=f"card_{i}")]
        for i, c in enumerate(cards)
    ])
    await callback.message.answer("Твои карточки:", reply_markup=kb)
    await callback.answer()

# Открыть карточку
@dp.callback_query(F.data.startswith("card_"))
async def open_card(callback: types.CallbackQuery):
    user_id = callback.from_user.id
    index = int(callback.data.split("_")[1])
    card = user_cards[user_id][index]

    text = f"Негатив: {card['neg']}
Альтернатива: {card['pos']}
Переворотов: {card['flips']}/30"

    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔄 Перевернуть", callback_data=f"flip_{index}")],
        [InlineKeyboardButton(text="✏ Редактировать", callback_data=f"edit_{index}")],
        [InlineKeyboardButton(text="🗑 Удалить", callback_data=f"del_{index}")],
        [InlineKeyboardButton(text="➡ Следующая", callback_data=f"next_{index}")]
    ])
    await callback.message.answer(text, reply_markup=kb)
    await callback.answer()

# Переворот
@dp.callback_query(F.data.startswith("flip_"))
async def flip_card(callback: types.CallbackQuery):
    user_id = callback.from_user.id
    index = int(callback.data.split("_")[1])
    card = user_cards[user_id][index]

    if card["flips"] >= 30:
        await callback.message.answer("Карточка достигла лимита 30 переворотов и удалена.")
        user_cards[user_id].pop(index)
        return

    card["flips"] += 1
    text = f"**Переворот {card['flips']}/30**

👉 {card['pos']}"
    await callback.message.answer(text, reply_markup=main_menu())
    await callback.answer()

# Редактирование
@dp.callback_query(F.data.startswith("edit_"))
async def edit_card(callback: types.CallbackQuery, state: FSMContext):
    index = int(callback.data.split("_")[1])
    user_id = callback.from_user.id
    edit_mode[user_id] = index
    await state.set_state(EditThought.waiting_for_edit)
    await callback.message.answer("Введи новую альтернативу для этой карточки:")
    await callback.answer()

@dp.message(EditThought.waiting_for_edit)
async def save_edit(message: types.Message, state: FSMContext):
    user_id = message.from_user.id
    index = edit_mode.get(user_id)

    if index is not None:
        user_cards[user_id][index]["pos"] = message.text.strip()
        await message.answer("Карточка обновлена!", reply_markup=main_menu())
        edit_mode.pop(user_id, None)

    await state.clear()

# Удаление
@dp.callback_query(F.data.startswith("del_"))
async def delete_card(callback: types.CallbackQuery):
    user_id = callback.from_user.id
    index = int(callback.data.split("_")[1])
    user_cards[user_id].pop(index)
    await callback.message.answer("Карточка удалена.", reply_markup=main_menu())
    await callback.answer()

# Следующая карточка
@dp.callback_query(F.data.startswith("next_"))
async def next_card(callback: types.CallbackQuery):
    user_id = callback.from_user.id
    index = int(callback.data.split("_")[1]) + 1
    cards = user_cards.get(user_id, [])

    if index >= len(cards):
        await callback.message.answer("Это была последняя карточка.", reply_markup=main_menu())
        return

    card = cards[index]
    text = f"Негатив: {card['neg']}
Альтернатива: {card['pos']}
Переворотов: {card['flips']}/30"
    await callback.message.answer(text, reply_markup=main_menu())
    await callback.answer()

# --- Запуск ---
async def main():
    await dp.start_polling(bot)

if __name__ == "__main__":
    import asyncio
    asyncio.run(main())
