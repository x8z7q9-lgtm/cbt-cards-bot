# CBT Cards Bot

Телеграм-бот для когнитивных карточек.

## Переменные окружения:
- BOT_TOKEN — токен Telegram бота
- OPENROUTER_KEY — ключ OpenRouter API

## Запуск локально
```bash
pip install -r requirements.txt
python cbt_cards_bot.py
```

## Деплой на Railway
Просто загрузите этот проект и настройте переменные окружения.
